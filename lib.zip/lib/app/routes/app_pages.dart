import 'package:get/get.dart';
import '../../Feature-based/Landing_screens/landing_screen1.dart';
import '../../Feature-based/Landing_screens/landing_screen2.dart';
import '../../Feature-based/auth/auth_binding/login_bindings.dart';
import '../../Feature-based/auth/login_view/loginScreen.dart';
import '../../Feature-based/auth/registration/register_bindings/reg_binding.dart';
import '../../Feature-based/auth/registration/registration_screen.dart';
import '../../Feature-based/forget_password/foget_password.dart';
import '../../Feature-based/profile/profile_binding/profile_binding.dart';
import '../../Feature-based/profile/profile_page.dart';
import '../../Feature-based/splash_screen/splashscreen.dart';
import '../../madhanvasu_lib/aswini_screens/home_page.dart';
import '../../main.dart';
import 'app_routes.dart';

class AppPages {
  static final pages = [
    GetPage(
      name: AppRoutes.decide,
      page: () => const DecideScreen(),
    ),
    GetPage(
      name: AppRoutes.landing,
      page: () => const Landing_screen_1(),
    ),

    GetPage(
      name: AppRoutes.landing2,
      page: () => const Landing_screen_2(),
    ),

    GetPage(
      name: AppRoutes.SplashScreen,
      page: () => const SplashScreen(),
    ),

    GetPage(
      name: AppRoutes.home,
      page: () => RealEstateHomeScreen(),
    ),
    GetPage(
      name: AppRoutes.register,
      page: () => RegistrationScreen(),
      binding: RegistrationBinding(),
    ),
    GetPage(
      name: AppRoutes.login,
      page: () => Login_Screen(toggleTheme: () {}),
      binding: LoginBinding(),
    ),

    GetPage(
      name: AppRoutes.ForgetPassword,
      page: () => ForgetPasswordPage(),
      // binding: LoginBinding(),
    ),

    GetPage(
      name: '/profile',
      page: () => const ProfileScreen(),
        binding: ProfileBinding()
    ),



  ];
}
