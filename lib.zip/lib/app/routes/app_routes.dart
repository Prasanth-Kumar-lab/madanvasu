abstract class AppRoutes {
  static const decide = '/';
  static const home = '/home';
  static const landing = '/landing';
  static const landing2 = '/Landing_screen_2';
  static const SplashScreen = '/SplashScreen';

  static const register = '/register';
  static const ForgetPassword = '/ForgetPassword';
  static const login = '/login';

  static const profile = '/profile';



}
