class ApiEndpoints {
  // static const String baseUrl = 'https://vivinindoorstadium.com/vivin';

  static const String baseUrl = 'https://madanvasu.in/new';


  static const String loginUrl = '/apis/api_users/user_login';

  static const String registerUser = '/apis/api_users/user_reg';



}
