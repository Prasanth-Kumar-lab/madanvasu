import 'package:flutter/material.dart';
// import 'package:real_estate/aswini_screens/comments_screen.dart';
import 'package:translator/translator.dart';

import 'comments_screen.dart';

class PropertyDetailsScreen extends StatefulWidget {
  final String propertyName;
  final String location;
  final String price;

  const PropertyDetailsScreen({
    super.key,
    required this.propertyName,
    required this.location,
    required this.price,
  });

  @override
  State<PropertyDetailsScreen> createState() => _PropertyDetailsScreenState();
}

class _PropertyDetailsScreenState extends State<PropertyDetailsScreen> {
  int selectedTab = 0; // 0: Overview, 1: Highlights, 2: Reviews

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFFDE7),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFFe57c42)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Property Details',
          style: TextStyle(color: Colors.black),
        ),
        iconTheme: const IconThemeData(color: Color(0xFFe57c42)),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Property Summary Card with Action Buttons
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(top: 10),
              child: Card(
                elevation: 3,
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                margin: EdgeInsets.zero,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xFFe4b201), width: 1.5),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.propertyName,
                        style: const TextStyle(
                          color: Color(0xFFe4b201),
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.location_on, color: Color(0xFFe57c42)),
                          const SizedBox(width: 4),
                          Text(
                            widget.location,
                            style: const TextStyle(fontSize: 16, color: Colors.black),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        widget.price,
                        style: const TextStyle(
                          color: Color(0xFF179a3a),
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        "This elegant property features modern amenities, spacious interiors, and a great neighborhood. Perfect for families or professionals looking for comfort and convenience.",
                        style: TextStyle(fontSize: 14, color: Colors.black87),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.share, color: Color(0xFFe57c42)),
                            tooltip: 'Share',
                          ),
                          ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFe57c42),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            child: const Text("Contact",style: TextStyle(color: Colors.white),),
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.favorite_border, color: Color(0xFFe57c42)),
                            tooltip: 'Like',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Tab Buttons: Overview | Highlights | Reviews
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  buildTabButton("Overview", 0),
                  buildTabButton("Highlights", 1),
                  buildTabButton("Reviews", 2),
                ],
              ),
            ),

            // Tab Content
            if (selectedTab == 0) buildOverviewTab(),
            if (selectedTab == 1) buildHighlightsTab(),
            if (selectedTab == 2) const CommentsSection(),
          ],
        ),
      ),
    );
  }

  Widget buildTabButton(String label, int index) {
    return TextButton(
      onPressed: () => setState(() => selectedTab = index),
      child: Text(
        label,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 16,
          color: selectedTab == index ? const Color(0xFFe4b201) : Colors.black54,
         // decoration: selectedTab == index ? TextDecoration.underline : TextDecoration.none,
        ),
      ),
    );
  }

 Widget buildOverviewTab() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 10),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0xFFe4b201), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Text(
            "Property Details",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFFe4b201),
            ),
          ),
          SizedBox(height: 10),
          DetailRow(label: "Property ID", value: "RV151"),
          DetailRow(label: "Price", value: "\$484,400"),
          DetailRow(label: "Property Size", value: "1466 Sq Ft"),
          DetailRow(label: "Bedrooms", value: "4"),
          DetailRow(label: "Bathrooms", value: "2"),
          DetailRow(label: "Garage", value: "1"),
          DetailRow(label: "Garage Size", value: "458 SqFt"),
          DetailRow(label: "Year Built", value: "2019-01-09"),
          DetailRow(label: "Property Type", value: "Full Family Home"),
          DetailRow(label: "Property Status", value: "For rent"),
          SizedBox(height: 16),
          Text(
            "Additional Details",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFFe4b201),
            ),
          ),
          SizedBox(height: 10),
          DetailRow(label: "Deposit", value: "30%"),
          DetailRow(label: "Pool Size", value: "457 Sqft"),
          DetailRow(label: "Last remodel year", value: "1956"),
          DetailRow(label: "Amenities", value: "Clubhouse"),
          DetailRow(label: "Additional Rooms", value: "Guest Bat"),
          DetailRow(label: "Equipment", value: "Grill - Gas - light"),
        ],
      ),
    ),
  );
}

  Widget buildHighlightsTab() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: const Color(0xFFe4b201), width: 1.5),
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Nearby Landmarks",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFFe4b201),
              ),
            ),
            SizedBox(height: 10),
            DetailRow(label: "School", value: "Sunrise Public School - 500m"),
            DetailRow(label: "Hospital", value: "City Care Hospital - 1.2km"),
            DetailRow(label: "Supermarket", value: "Reliance Mart - 800m"),
            DetailRow(label: "Park", value: "Greenview Park - 400m"),
            DetailRow(label: "Metro Station", value: "Sector 21 Metro - 1.5km"),
          ],
        ),
      ),
    );
  }
}

// DetailRow Widget
class DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const DetailRow({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              "$label:",
              style: const TextStyle(fontWeight: FontWeight.w500, color: Colors.black87),
            ),
          ),
          Expanded(
            flex: 5,
            child: Text(
              value,
              style: const TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
