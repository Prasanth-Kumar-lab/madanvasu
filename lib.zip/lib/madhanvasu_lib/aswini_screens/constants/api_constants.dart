class ApiEndpoints { 
  static const String baseUrl ='https://madanvasu.in/new/';
  static const String loginUrl = '/apis/api_users/user_login';
  static const String regUrl = '/apis/api_users/user_reg';
  static const String forgotUrl = '/apis/api_users/user_forgot';
}
