import 'package:flutter/material.dart';
import 'package:translator/translator.dart';

class CommentsSection extends StatefulWidget{
  const CommentsSection({super.key});

  @override 
  State<CommentsSection> createState() => _CommentsSectionState();
}
class _CommentsSectionState extends State<CommentsSection> {
  final translator = GoogleTranslator();
  final TextEditingController _commentController = TextEditingController();

  final List<Map<String, dynamic>> Comments = [
    {"original": "यह एक बहुत अच्छा घर है!", "translated":null, "isTranslated":false},
    {"original": "La casa es muy espaciosa.", "translated": null, "isTranslated": false},
    {"original": "Très bonne propriété avec des équipements modernes.", "translated": null, "isTranslated": false},
    {"original": "ఈ ఇల్లు చాలా బాగుంది.", "translated": null, "isTranslated": false},
    {"original": "విశాలమైన మరియు అందమైన ఇల్లు", "translated": null, "isTranslated": false},

  ];

  void toggleTranslation(int index) async {
    final Comment = Comments[index];
    if (!Comment['isTranslated']) {
      if (Comment['translated']== null) {
        final translation = await translator.translate(Comment['original'],to: 'en');
        setState(() {
          Comment['translated'] = translation.text;
          Comment['isTranslated'] = true;
        });
      } else {
        setState(() => Comment['isTranslated'] = true);
      }
    } else{
      setState(() => Comment['isTranslated'] = false);
    }
  }
  void addComment(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      Comments.insert(0, {
        "original": text.trim(),
        "translated":null,
        "isTranslated": false,
      });
      _commentController.clear();
    });
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border:  Border.all(color: Color(0xFFe4b201),width:1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Add a Comment",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Color(0xFFe4b201),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _commentController,
            onSubmitted: addComment,
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              hintText: " Write your comment...",
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color:  Color(0xFFe4b201)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color:  Color(0xFFe4b201),width: 2),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              suffixIcon: IconButton(
                icon:  const CircleAvatar(
                  backgroundColor:  Color(0xFFe57c42),
                  radius: 15,
                  child: Icon(Icons.arrow_upward, size: 18, color: Colors.white),
                ),
                onPressed: () => addComment(_commentController.text),
                tooltip: "Post Comment",
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            "Comments & Reviews",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFFe4b201),
            ),
          ),
          const SizedBox(height: 16),
          ...Comments.asMap().entries.map((entry) {
            final index = entry.key;
            final Comment = entry.value;
            final displayText = Comment['isTranslated']
                 ? Comment['translated'] ?? Comment['original']
                 :Comment['original'];
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const CircleAvatar(
                    radius: 16,
                    backgroundColor: Color(0xFFe57c42),
                    child: Icon(Icons.person, color: Colors.white,size: 18,),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Text(
                    displayText,
                    style: const TextStyle(fontSize: 14, color: Colors.black),
                  ),),
                  TextButton(onPressed: () => toggleTranslation(index), 
                  child: Text(
                    Comment['isTranslated'] ? "See Original" : "Translate",
                    style: const TextStyle(color: Color(0xFFe57c42),fontSize: 13),
                  ),
                  ),
                ],
              ),
            );
          })
        ],
      ),
    );
  }
}
