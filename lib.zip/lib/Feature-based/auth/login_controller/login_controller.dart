import 'package:get/get.dart';
import 'package:madhanvasu_app/Feature-based/auth/loging_model/login_model.dart';
import '../../../data/Api_services/user_api_services.dart';
import '../../../utils/shared_pref_helper.dart';

class LoginController extends GetxController {
  var isLoading = false.obs;

  void setLoading(bool value) {
    isLoading.value = value;
  }

  ///// Login user with username, password, and FCM token
  Future<bool> loginUser(String username, String password, String fcmToken) async {
    try {
      setLoading(true);

      //  Send FCM token to the API
      LoginModel? loginModel = await ApiService.login(username, password, fcmToken);

      setLoading(false);

      if (loginModel != null && loginModel.status && loginModel.data.isNotEmpty) {
        Datum user = loginModel.data[0];

        //  Save user data to shared preferences
        await SharedPrefHelper.saveUserData({
          'id': user.id,
          'personName': user.personName,
          'email': user.email,
          'mobileNumber': user.mobileNumber,
          'role': user.role,
          'locationId': user.locationId,
          'profile_image': user.profileImage,
        });

        await SharedPrefHelper.setLoggedIn(true);

        print('Login successful: User ${user.personName}');
        return true;
      } else {
        print(' Login failed: Invalid response or empty user data');
        return false;
      }
    } catch (e) {
      setLoading(false);
      print('Login error: $e');
      return false;
    }
  }
}
