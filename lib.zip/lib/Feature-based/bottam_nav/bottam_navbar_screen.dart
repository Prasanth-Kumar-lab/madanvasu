// import 'package:flutter/material.dart';
//
// import '../../app/configuration/ themes/app_colors.dart';
// import '../../app/utils/shared_pref_helper.dart';
// import '../../madhanvasu_lib/aswini_screens/home_page.dart';
// import '../../madhanvasu_lib/ui_screens/post_propertys.dart';
// import '../../madhanvasu_lib/ui_screens/saved_propertys.dart';
// import '../profile/profile_page.dart';
//
// class CustomBottomNavigationBar extends StatefulWidget {
//   final int currentIndex;
//   final VoidCallback toggleTheme;
//
//
//   const CustomBottomNavigationBar({
//     super.key,
//     required this.currentIndex,
//     required this.toggleTheme, required void Function(int index) onTap,
//   });
//
//   @override
//   State<CustomBottomNavigationBar> createState() => _CustomBottomNavigationBarState();
// }
//
// class _CustomBottomNavigationBarState extends State<CustomBottomNavigationBar> {
//   Map<String, String> userData = {};
//
//   @override
//   void initState() {
//     super.initState();
//     _loadUserData();
//   }
//
//   Future<void> _loadUserData() async {
//     final keys = [
//       'id',
//       'personName',
//       'email',
//       'mobileNumber',
//       'locationId',
//       'role',
//       'profile_image'
//     ];
//     Map<String, String> loadedData = {};
//
//     for (String key in keys) {
//       final value = await SharedPrefHelper.getUserData(key);
//       if (value != null) {
//         loadedData[key] = value;
//       }
//     }
//
//     setState(() {
//       userData = loadedData;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return BottomNavigationBar(
//       // backgroundColor: AppColors.primary.withOpacity(0.6),
//       backgroundColor:AppColors.border, ///white
//
//       items: const [
//         BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
//         BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Saved'),
//         BottomNavigationBarItem(icon: Icon(Icons.post_add), label: 'Post'),
//         BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
//       ],
//       currentIndex: widget.currentIndex,
//       selectedItemColor: AppColors.primary,
//       unselectedItemColor: Colors.grey,
//       onTap: (index) {
//         switch (index) {
//           case 0:
//             if (widget.currentIndex != 0) {
//               Navigator.pushReplacement(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) =>
//                   // LocationScreen(toggleTheme: toggleTheme),
//                   RealEstateHomeScreen(),
//                 ),
//               );
//             }
//             break;
//           case 1:
//             if (widget.currentIndex != 1) {
//               // Navigator.pushReplacement(
//               //   context,
//               //   MaterialPageRoute(
//               //     builder: (context) =>
//               //         BookingsScreen(toggleTheme: toggleTheme),
//               //   ),
//               // );
//               Navigator.push(context, MaterialPageRoute(builder: (_)=>SavedPropertiesScreen()));
//             }
//             break;
//           case 2:
//             if (widget.currentIndex != 2) {
//               Navigator.pushReplacement(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => PostPropertyScreen(),
//                 ),
//               );
//             }
//             break;
//           case 3:
//             if (widget.currentIndex != 2) {
//               Navigator.pushReplacement(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => ProfileScreen(),
//                 ),
//               );
//             }
//             break;
//         }
//       },
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomBottomNavigationBar extends StatelessWidget {
  final int currentIndex;
  final VoidCallback toggleTheme;

  // Add colors for styling
  final Color primaryColor;
  final Color bottomNavbarColor;
  final Color cardColor;

  const CustomBottomNavigationBar({
    Key? key,
    required this.currentIndex,
    required this.toggleTheme,
    required this.primaryColor,
    required this.bottomNavbarColor,
    required this.cardColor,
  }) : super(key: key);

  void _handleNavigation(int index) {
    switch (index) {
      case 0:
        Get.offAllNamed('/home');
        break;
      case 1:
        Get.toNamed('/saved');
        break;
      case 2:
        Get.toNamed('/post');
        break;
      case 3:
        Get.toNamed('/profile');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: _handleNavigation,
      selectedItemColor: bottomNavbarColor,
      unselectedItemColor: bottomNavbarColor.withOpacity(0.9),
      backgroundColor: cardColor,
      type: BottomNavigationBarType.fixed,
      selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
      unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w400, fontSize: 12),
      elevation: 8,
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined, size: 30),
          label: 'Home',
          activeIcon: Icon(Icons.home, size: 28, color: primaryColor),
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.favorite_border, size: 28),
          label: 'Saved',
          activeIcon: Icon(Icons.favorite, size: 28, color: primaryColor),
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.post_add_outlined, size: 28),
          label: 'Post',
          activeIcon: Icon(Icons.post_add, size: 28, color: primaryColor),
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person_outline, size: 28),
          label: 'Profile',
          activeIcon: Icon(Icons.person, size: 28, color: primaryColor),
        ),
      ],
    );
  }
}

