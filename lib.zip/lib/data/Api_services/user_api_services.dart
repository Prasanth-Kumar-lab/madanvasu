import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../Feature-based/auth/loging_model/login_model.dart';
import '../../app/configuration/ themes/api_end_points.dart';

class ApiService {
  ///////////////// LOGIN API

  static Future<LoginModel?> login(
      String username,
      String password,
      String fcmToken,
      ) async {
    try {
      print('FCM Token: $fcmToken');

      var url = Uri.parse('${ApiEndpoints.baseUrl}${ApiEndpoints.loginUrl}');
      print('Login API URL: $url');
      var request = http.MultipartRequest('POST', url);

      request.fields.addAll({
        'username': username,
        'password': password,
        'active_status': 'Active',
        'fcm_token': fcmToken,
      });

      request.headers.addAll({
        'Cookie': 'ci_session=e505572173f95a9ade95649e3cc7361d0a43bf68',
      });

      http.StreamedResponse response = await request.send();

      if (response.statusCode == 200) {
        final responseString = await response.stream.bytesToString();
        print('Response Bodyyyyyyy: $responseString');

        final jsonResponse = jsonDecode(responseString);

        if (jsonResponse['status'] == true && jsonResponse['data'] != null) {
          return LoginModel.fromJson(jsonResponse);
        } else {
          print("Login failed: ${jsonResponse['message'] ?? 'Unknown error'}");
          return null;
        }
      } else {
        print('HTTP Error: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      print('Login API Exception: $e');
      return null;
    }
  }


  ////////////////// REGISTER API

  static Future<bool> registerUser({
  required String name,
  required String email,
  required String phone,
  required String password,
}) async {
  try {
    // var url = Uri.parse('https://madanvasu.in/new/apis/api_users/user_reg');

    var url = Uri.parse('${ApiEndpoints.baseUrl}${ApiEndpoints.registerUser}');
    print('registerUser API URL: $url');


    var request = http.MultipartRequest('POST', url);

    request.fields.addAll({
      'person_name': name,              
      'email': email,
      'mobile_number': phone,
      'password': password,
      'terms_conditions': 'Agreed',     
      'location_id': '1',               
    });

    print('Sending fields: ${request.fields}');

    final response = await request.send();
    final responseString = await response.stream.bytesToString();
    print('Response Body: $responseString');

    final json = jsonDecode(responseString);
    return json['status'] == true;
  } catch (e) {
    print(' Registration exception: $e');
    return false;
  }
}



}
